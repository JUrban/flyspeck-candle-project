#include <float.h>
#include "interval.h"
#include "lineInterval.h"
#include "univariate.h"
#include "secondDerive.h"
#include "taylorData.h"
#include "Lib.h"
#include "recurse.h"
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cmath>
int main(int argc,char** argv) {
  if(argc>1 && std::string(argv[1])=="selftest") {
    interMath::selfTest(); linearization::selfTest(); univariate::selfTest(); secondDerive::selfTest(); Function::selfTest(); Lib::selfTest();
    std::printf("AUDIT selftests errors=%d\n",error::get_error_count()); return error::get_error_count()!=0;
  }
  bool generic=(argc>1 && std::string(argv[1])=="generic") || (argc>3 && std::string(argv[3])=="generic");
  Function angle=Lib::dih_x;
  if(generic) angle=Lib::constant6(interval("1.570796326794896619231321691639751442")) + Lib::uni(univariate::i_atan,(Lib::delta_x4*interval("-1")) / Lib::uni(univariate::i_sqrt,Lib::x1*Lib::delta_x*interval("4")));
  Function f=Lib::constant6(interval("1.277") - interval("0.273298")*interval("2.18") + interval("0.273853")*interval("4") - interval("0.708818")*interval("2") + interval("0.313988")*interval("4"))
   + Function::uni_slot(univariate::i_sqrt,0)*interval("0.273298")
   + Function::uni_slot(univariate::i_sqrt,1)*interval("-0.273853")
   + Function::uni_slot(univariate::i_sqrt,2)*interval("-0.273853")
   + Function::uni_slot(univariate::i_sqrt,3)*interval("0.708818")
   + Function::uni_slot(univariate::i_sqrt,4)*interval("-0.313988")
   + Function::uni_slot(univariate::i_sqrt,5)*interval("-0.313988")
   + angle*interval("-1");
  const char* low_text[6]={"4.7524","4","4","4","4","4"};
  const char* high_text[6]={"6.3504","4.7524","4.7524","5.0625","5.0625","5.0625"};
  double lo[6],hi[6];for(int i=0;i<6;i++){lo[i]=interMath::inf(interval(low_text[i]));hi[i]=interMath::sup(interval(high_text[i]));}
  if(argc>1 && std::string(argv[1])=="search") {
   double x0[6],z0[6];for(int i=0;i<6;i++){x0[i]=lo[i];z0[i]=hi[i];}
   const Function* fs[1]={&f};cellOption opt;opt.printingMode=cellOption::silent;opt.timeout=30;opt.iterationLimit=1000000;
   if(argc>2)opt.allowDerivatives=atoi(argv[2]);
   auto a=std::chrono::steady_clock::now();int ok=prove::recursiveVerifier(0,lo,hi,x0,z0,fs,1,opt);auto b=std::chrono::steady_clock::now();
   std::printf("AUDIT search ok=%d cells=%d wall=%.9f errors=%d\n",ok,prove::get_cellcount(),std::chrono::duration<double>(b-a).count(),error::get_error_count());
  } else {
   const int n=10000;double accum=0;int negative=0;
   auto a=std::chrono::steady_clock::now();
   for(int j=0;j<n;j++) {
    double x[6],z[6];for(int k=0;k<6;k++){double t=double((j*(17+2*k))%997)/997.0;x[k]=lo[k]+(hi[k]-lo[k])*t*0.98;z[k]=x[k]+(hi[k]-lo[k])*.005;}
    taylorData td=f.evalf(domain(x),domain(z));double v=td.upperBound();accum+=v;negative+=v<0;
   }
   auto b=std::chrono::steady_clock::now();
   std::printf("AUDIT boxes=%d accepted=%d wall=%.9f checksum=%.17g errors=%d\n",n,negative,std::chrono::duration<double>(b-a).count(),accum,error::get_error_count());
  }
}