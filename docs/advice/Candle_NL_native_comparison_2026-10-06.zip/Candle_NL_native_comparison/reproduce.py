#!/usr/bin/env python3
"""Download pinned historical code and run a diagnostic, unverified comparison.

Usage: python3 reproduce.py
Requires Python 3, g++, patch, and network access to raw.githubusercontent.com.
Writes only inside a new/reusable build directory beside this script.
No result from this program constitutes a formal proof.
"""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import urllib.request

root = Path(__file__).resolve().parent
build = root / 'build'
build.mkdir(exist_ok=True)
spec = json.loads((root / 'sources.json').read_text())
prefix = ('https://raw.githubusercontent.com/' + spec['repository'] + '/'
          + spec['commit'] + '/' + spec['directory'] + '/')

def download(item):
    name, expected = item
    path = build / name
    if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest() == expected:
        return
    data = urllib.request.urlopen(prefix + name, timeout=60).read()
    assert hashlib.sha256(data).hexdigest() == expected, name
    path.write_bytes(data)

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(download, spec['files'].items()))

# Preserve original downloads. Make separate, explicitly patched copies.
replacements = {
    'Lib.cc': [('// all second partials are pm 0,1,2.  \n}',
                '// all second partials are pm 0,1,2.  \n  return 1; // audit: missing success return\n}')],
    'univariate.cc': [
        ('    data[it->first]=it->second;\n}\n\n\nunivariate::univariate(uniprimitive* p)',
         '    data[it->first]=it->second;\n  return *this; // audit: missing assignment return\n}\n\n\nunivariate::univariate(uniprimitive* p)'),
        ('  epsilonClose(f[i],interMath::sup(u.eval(x,i)),1.0e-8);\n  }\n}',
         '  epsilonClose(f[i],interMath::sup(u.eval(x,i)),1.0e-8);\n  }\n  return 1; // audit: test helper return\n}')],
    'secondDerive.cc': [('  DDf[0][5] = DDf[5][0];\n}',
                         '  DDf[0][5] = DDf[5][0];\n  return 1; // audit: missing success return\n}')]
}
for name, changes in replacements.items():
    text = (build / name).read_text()
    for before, after in changes:
        assert text.count(before) == 1, name
        text = text.replace(before, after)
    (build / ('audit_compat_' + name)).write_text(text)
shutil.copyfile(root / 'audit_benchmark.cc', build / 'audit_benchmark.cc')

modules = 'error interval lineInterval secondDerive univariate wide taylorData Lib recurse'.split()
options = {'interval': '-O0', 'univariate': '-O0', 'lineInterval': '-O0', 'secondDerive': '-O1'}
common = ['-std=gnu++11', '-frounding-math', '-ffp-contract=off', '-include', 'cstring', '-Wno-write-strings']

def compile_one(module):
    source = ('audit_compat_' if module + '.cc' in replacements else '') + module + '.cc'
    subprocess.run(['g++'] + common + [options.get(module, '-O2'), '-c', source, '-o', module + '.o'], cwd=build, check=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(compile_one, modules))
subprocess.run(['g++'] + common + ['-O0', 'audit_benchmark.cc']
               + [m + '.o' for m in modules] + ['-lm', '-o', 'benchmark'], cwd=build, check=True)

rows = []
for arguments in [['selftest'], [], ['generic'], ['search', '1'], ['search', '1', 'generic'], ['search', '1'], ['search', '0']]:
    result = subprocess.run(['./benchmark'] + arguments, cwd=build,
                            capture_output=True, text=True, timeout=60)
    row = {'args': arguments, 'status': result.returncode,
           'stdout': result.stdout, 'stderr': result.stderr}
    rows.append(row)
    print(arguments, '\n'.join(line for line in result.stdout.splitlines() if line.startswith('AUDIT')), flush=True)
    if result.returncode:
        raise RuntimeError(row)
(root / 'reproduced_results.json').write_text(json.dumps(rows, indent=2))
