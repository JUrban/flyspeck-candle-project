Candle nonlinear performance audit and C++ diagnostic benchmark
6 October 2026

Run python3 reproduce.py to download hash-checked historical sources, build
the diagnostic driver, run numerical self-tests, and repeat the comparisons.
Requires Python 3 and g++. The historical source is downloaded, not bundled.
This is an unverified diagnostic program. It is not a formal proof or a
replacement for the Candle checker. No project repository was modified.

SOURCE PINS

Candle branch codex/cv-nl-raw-batch-slicing-v1:
64ea574af950feb6025f50520b37722fc085c6e9
Project branch codex/nl-bounded-group83-v1:
f3a870776983c5ea78dc2fa14e92c0922155cd12
Project progress documents read from earlier NL-equivalent snapshot:
311be8a402edc1911f00f0dd5a7e576a90124db0
Original 1998 archive flyspeck/kepler98:
90350ab8b897a577c16cff2bd72643b3f9e32227
Later untrusted Flyspeck C++ implementation flyspeck/flyspeck:
1ce0353008eba83d3c76ae9a25c3c242e4802d53

There are two historical programs. The 1998 archive establishes the old
architecture; the later C++ code supplies a meaningful comparison with a
current Flyspeck inequality. They must not be conflated.

EXPERIMENT

The driver reconstructs parent inequality 8657368829, whose two domain
halves appear as Flyspeck records 10172 and 10173. It is a linear combination
of six square roots and a dihedral angle on a six-dimensional box. Exact
decimal coefficients are supplied to the original interval string parser;
domain endpoints are rounded outward with that parser in the final run.

Mode 1 uses the original specialized Lib::dih_x primitive.
Mode 2 expresses the same angle through the C++ library's generic composition
of its delta/delta_x4 primitives, square root, reciprocal, and arctangent.
Mode 2 is not a literal implementation of Candle's fixed-scale algorithm.

The final locally measured results (native_final_results.json) are:

Specialized search, derivatives enabled: 0.346080361 and 0.320280561 seconds;
5,334 reported cell visits in both runs.
Generic-composition search: 13.198868746 seconds; 84,016 reported cell visits.
This is about 39.6x wall time against the mean adjacent specialized controls,
and 15.75x visits. The timing ratio is an observation on this local build,
not a prediction of an achievable Candle optimization.
Specialized search without derivative pruning: 0.484230266 seconds;
8,896 reported visits.

On the same 10,000 deterministic small subboxes inside the domain:
specialized 0.544907980 seconds, generic 1.526709893 seconds. All were accepted
in both runs. These are synthetic diagnostic subboxes, not the actual Candle
certificate cells. The two enclosure checksums differ, as expected, because
equivalent expressions produce different interval bounds.

Full search includes unsuccessful coarse-box attempts and internal nodes.
Reflected certificate-cell counts count accepted numerical jobs. These
counters are not interchangeable.

PORTABILITY AND VALIDATION

The initial all-O2 build failed an original interval rounding self-test.
It is excluded from the accepted comparison. Rebuilding with the per-file
optimization levels in the original makefile resolved that failure.
Sanitizers then identified four missing returns in the historical C++ source.
The explicit patch adds returns in an assignment operator, a test helper,
and two derivative-bound callbacks. Original downloaded files are preserved;
separate audit_compat copies are compiled. The final build passes interval,
lineInterval, univariate, secondDerive, Function, and Lib self-tests with
zero reported errors. Passing those tests does not certify modern floating
point execution. Earlier rejected/intermediate runs are included for audit,
and must not be used as the final benchmark.

The generic search prints recoverable division-by-zero interval diagnostics
on coarse boxes, then subdivides and succeeds. Its final error count is zero.

HISTORICAL AND CURRENT COMPARISON

The original informal_code/interval_code/qed_log_2012.txt records parent
8657368829 at 2,189 ms and 5,354 cells on 16 August 2013. It also records
2,037 ms and 5,354 cells in October 2012. These are historical runs with
historical hardware and code revisions, not controlled same-machine tests.

Current reflected results in project progress v3.17 and v3.15 respectively:
10172: 157.750 seconds Kernel.compute + 16.740 handoff + 0.202 source;
       1,538 numerical cells; total 174.692 seconds from encoded input.
10173: 434.363713 seconds Kernel.compute + 46.468051 handoff + 0.100958 source;
       4,173 numerical cells; total 480.932722 seconds from encoded input.
Combined recurring proof cost is 655.624722 seconds, excluding preparation.
Historical native formal Flyspeck total times are 667.725002 and 2084.239248
seconds respectively. Those totals include preparation, so they do not give
a formal-checking-only speedup. All cross-runtime historical ratios have
hardware and boundary differences.

SOURCE FINDINGS

1. Kernel.compute already avoids individual logical proof construction per
   arithmetic operation. Its execute engine is nevertheless an interpreter
   of first-order expression data, with Num/Pair values, environment lists,
   function lookup, primitive dispatch, and allocation. The checker itself
   interprets the numerical postfix program inside that engine. This is
   different from native C++ execution of specialized numerical functions.

2. Original kepler98 interval/taylorInterval.cc calls specialized derivative
   routines and, for some specific functions and domains, copies previously
   established Hessian bound tables. These tables do not apply indiscriminately
   to every current benchmark. Original secondDerive.cc exploits identities,
   sparsity, and matrix symmetry. Later C++ retains these design choices.

3. Current candle/cv_compute_analytic_expr_fixed_scale_compute.ml represents
   a signed numerator by two naturals. candle_cv_fs_raw_mul_def performs four
   natural multiplications. candle_cv_fs_raw_interval_mul_def computes four
   endpoint products for the lower bound and the same four again for the
   upper bound: 32 natural multiplications per interval multiplication.
   This is a static operation count, not a measured 16x speed prediction.
   Native positive-interval multiplication uses two double products; other
   sign combinations use optimized cases. Current fixed-scale 10^12 arithmetic
   still creates roughly 80-bit intermediate products for unit-size values,
   and uses division for outward rounding.

4. Current cv_compute_analytic_expr_taylor_model_program_fixed_nonlinear.ml
   propagates sqrt Hessians using dd*(g outer g) + d*H. In six dimensions this
   requires 36 interval products for the outer product, 36 to scale it, and
   36 to scale H: 108 interval products, or 3,456 natural multiplication
   calls with the implementation above, just for that Hessian propagation.
   It also performs matrix additions, rounding, and gradient/value work.
   This generic path applies even to sqrt(x_i). The old primitive_univariate
   directly computes its one nonzero diagonal second derivative and clears
   the other entries. The actual formula contains six such square roots.

5. Polynomial instructions eagerly complete value and gradient enclosures
   from center and Hessian information. This repeatedly traverses matrices,
   including zeros. The fixed-nonlinear implementation still calls the eager
   polynomial program. Proved lazy completion exists separately and showed
   approximately 12% full-program improvement on the older fixed-outer path;
   it is not a newly discovered optimization and is not enough by itself.

6. The current atan implementation uses exact normalized rational arithmetic
   for fixed alternating polynomials, with reciprocal range reduction but
   without the original C++ small-angle reductions. Its pointwise upper/lower
   gap for 0 <= t < 1 is t^13/13. At t=0.5 this is 9.39e-6; at t=0.9 it is
   0.01955. The old C++ rational approximation reduces arguments below
   tan(pi/16), then adds a 1e-10 error allowance. Its accuracy claims are
   unverified assumptions unless separately proved. A diagnostic sample of
   64 corners and 997 interior points of the actual benchmark parent has
   maximum |atan argument| about 0.52027 and maximum series gap 1.57e-5.
   This sample is not an interval enclosure proof or a runtime attribution.

7. GC/heap capacity is a measured major effect: project v2.96 reports the
   same 32 cells improving from 513.466 to 14.586099 seconds after moving to
   the large heap. Current 16 GiB-heap results already include this benefit.
   No profile establishes the remaining current GC percentage. Stable RSS
   does not show that allocation or GC is cheap.

8. Topology validation was 0.101 seconds versus roughly 24 seconds of complete
   computation on a 128-cell predecessor benchmark. Numerical evaluation,
   not tree bookkeeping, was dominant. The final current 10173 handoff is
   about 9.7% of compute-through-theorem cost; removing it cannot yield an
   order-of-magnitude improvement.

INTERPRETATION AND NEXT DISCRIMINATING EXPERIMENT

The reusable soundness/checker architecture has been achieved. The remaining
performance problem is substantially the numerical engine it verifies. It
uses more generic derivative work, more expensive scalar representations,
and interpreted data execution than the historical implementation.

The C++ control establishes that equivalent generic composition can lose
both per-box efficiency and enclosure tightness even without a proof kernel
or managed garbage collector. It does not prove that Candle currently loses
the same factor or visits the same larger tree. The present reflected cells
and the native C++ visit counter have different meanings.

The highest-value follow-up is one exported set of actual certificate boxes
for this parent, evaluated by specialized C++, generic native code, and the
current reflected checker. Record time, allocation/GC, scalar-operation
counts, Hessian work, and bound tightness separately. This removes search
and hardware confounders without requiring another long verifier load.

A promising architectural experiment is a proved numerical instruction for
sqrt of one coordinate, followed by a proved specialized dihedral primitive.
Keep the universal source/certificate soundness structure; extend its instruction
cases with reusable enclosures. Compare fixed certificate acceptance and
whole search size. Other candidates are sparse/symmetric Hessians, efficient
sign-aware rounded arithmetic, and reuse of proved coarse-domain derivative
bounds. They require measurement, not an assumed multiplication of savings.

Do not repeat already-rejected microbenchmarks blindly: the project has tested
endpoint sharing, generic untrusted execution, let sharing, and other small
changes, several with negative results. The earlier untrusted executor was
still an interpreter of the same encoded equations, not an efficient native
numerical baseline. Moving that same interpreter outside the kernel is not
the required algorithmic comparison.

No 1,000x or 10,000x verified speedup is established or promised by this audit.
The evidence identifies concrete structural gaps and a reproducible way to
test them, rather than attributing all remaining cost to proof or GC.
